# Online quiz portal

## Description
It is an online portal in which one can attend the quiz online and view the results immeadiately after completing the quiz

## Use of this Project
Using this portal one can attend the quiz virtually and view the scores in real time

## Stacks Used
* JavaScript
* HTML  
* CSS

## How to set up project
Download the zip file and copy all the files in the single folder. Open the folder in visual studio code and copy the path of the index file and paste it in the search box of  google chrome to view the output.

## ScreenShot

<img src="https://github.com/jyothi-k-g/online-quiz-poral/blob/main/images/s1.png" /> 

